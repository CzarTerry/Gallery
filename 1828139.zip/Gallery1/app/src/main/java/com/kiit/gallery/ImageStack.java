package com.kiit.gallery;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;


public class ImageStack extends BaseAdapter {
    private ArrayList<ImageContainer> stack;
    private Integer index;
    private Context context;


    ImageStack(Context context) {
        stack = new ArrayList<>();
        index = 0;
        this.context = context;
    }

    ImageStack(Context context, Bundle fromBundle) {
        this.context = context;
        this.stack = fromBundle.getParcelableArrayList("stack");
        this.index = fromBundle.getInt("index");
    }


    public ArrayList<ImageContainer> getStack() {
        return stack;
    }

    void setStack(ArrayList<ImageContainer> stack) {
        this.stack = stack;
        index = 0;
    }

    ImageContainer next() {
        if (index < stack.size()) {
            index++;
        }
        return stack.get(index);
    }

    ImageContainer previous() {
        if (index > 0) {
            index--;
        }
        return stack.get(index);
    }

    public ImageContainer first() {
        index = 0;
        return stack.get(index);
    }

    boolean hasNext() {
        return (index < stack.size() - 1);
    }

    boolean hasPrevious() {
        return (index >= 0);
    }

    void setIndex(Integer index) {
        this.index = index;
    }

    ImageContainer getCurrent() {
        return stack.get(index);
    }

    public void selectImage(ImageContainer selected) {
        index = stack.indexOf(selected);
    }

    Bundle toBundle() {
        Bundle out = new Bundle();

        out.putParcelableArrayList("stack", stack);
        out.putInt("index", index);

        return out;
    }

    @Override
    public int getCount() {
        return stack.size();
    }

    @Override
    public Object getItem(int position) {
        return stack.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(360, 360));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        ImageContainer container = stack.get(position);
        imageView.setImageBitmap(container.getThumbnail(context));

        return imageView;
    }
}
